'''
Created on May 24, 2015

@author: Caleb BG
'''
from Aliens_class import *
from random import *


class AliensGraphics:

        """ Particle background """
        @staticmethod
        def aliengraphics(displayw, displayh, spritegroups, playersprite, playergroup):
            
            player = playersprite
            
            playerspritegroup = playergroup
            
            randomspeed = randrange(1, 3)
            
            randlocx = randrange(20, displayw-31)
            randlocy = randrange(0, displayh-22)

            for x in range(0, 2):      # Default value is (0, 3)
                
                aliens = Aliens(displayw, displayh, spritegroups, player, playerspritegroup)
                aliens.set_position(randlocx, randlocy-800)
                aliens.changespeed(0, randomspeed)
                
                spritegroups.add(aliens)
                 
                """ Loop to kill sprites """
                for alien in spritegroups:
                    if alien.rect.y > displayh:
                        spritegroups.remove(alien)
