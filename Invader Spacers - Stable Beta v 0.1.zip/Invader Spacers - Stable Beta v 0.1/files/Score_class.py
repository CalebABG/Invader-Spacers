'''
Created on Aug 26, 2015

@author: Caleb
'''

import pygame
import sys 
import Tools_class

class Score(pygame.sprite.Sprite):
    
    def __init__(self, start, displayw, displayh, window):
        
        super(Score,self).__init__()
        
        