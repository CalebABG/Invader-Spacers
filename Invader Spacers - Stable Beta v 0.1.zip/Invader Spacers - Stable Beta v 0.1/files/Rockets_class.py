'''
Created on May 29, 2015

@author: Caleb BG
'''
import pygame
from pygame.locals import *

class RocketAttatchments(pygame.sprite.Sprite):
    
    def __init__(self, displaywidth, displayheight, spritegroup):
        
        super(RocketAttatchments, self).__init__()
        
        self.displayw = displaywidth
        
        self.displayh = displayheight
        
        self.spritegroups = spritegroup
        
        self.cooldown = 90
        
        self.lifetime = 200
    
        self.image = pygame.image.load("res/rocket.png").convert_alpha()
        
        self.rect = self.image.get_rect()
    
        self.hspeed = 0
        self.vspeed = 0

    def setposition(self, x, y):
        
        self.rect.x = x 
        self.rect.y = y
        
    def dead(self):
        pygame.sprite.Sprite.kill(self)
        return True
        
    def is_dead(self):
        
        if self.dead() == True:
            return True
        
        else:
            return False
       
        
    def update(self):
        
        self.lifetime -= 1
    
        self.rect.x += self.hspeed   
        self.rect.y += self.vspeed
        
        if self.rect.y > self.displayh or self.rect.y < 0:
            pygame.sprite.Sprite.kill(self)
            
        elif self.rect.y > self.displayw or self.rect.y < 0:
            pygame.sprite.Sprite.kill(self)
            
        elif self.lifetime == 0:
            pygame.sprite.Sprite.kill(self)
        
        hit_list = pygame.sprite.spritecollide(self, self.spritegroups, True)
        
        for x in self.spritegroups:
            for x in hit_list:
                pygame.sprite.Sprite.kill(x)
                self.dead()