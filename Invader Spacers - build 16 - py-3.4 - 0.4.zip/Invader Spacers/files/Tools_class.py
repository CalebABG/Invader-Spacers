'''
Created on May 14, 2015
@author: Caleb BG
'''

import pygame

class ScreenMessage(pygame.font.Font):

    def __init__(self, surface, msg, paint, fontsize, x, y):

        self.fontSize = fontsize

        font = pygame.font.SysFont("monospace", fontsize)

        self.msg = msg
        self.color = paint

        self.x = x
        self.y = y

        screentxt = font.render(msg, True, paint)

        surface.blit(screentxt, [x, y])