'''
Created on May 30, 2015

@author: Caleb BG
'''

import pygame
from pygame import gfxdraw

# Note to self: Create an arc sprite sheet for shield. Parent it above player (Ship) 
# Shield color...


class Shield(pygame.sprite.Sprite):
    
    def __init__(self, player_sprite, enemies):
        
        super(Shield, self).__init__()
        
        self.player = player_sprite
        
        self.enemies_group = enemies
        
        self.lifetime = 250
        
        self.radius = 50
        
        self.image = pygame.Surface((108, 108))
        
        pygame.gfxdraw.arc(self.image, self.radius, self.radius, self.radius, 180, 0, (0, 46, 184))
        
        self.image.set_colorkey((0, 0, 0))
        
        self.image = self.image.convert_alpha()
        
        self.rect = self.image.get_rect()

    def update(self):
        
        self.rect.center = self.player.rect.center
        
        if self.lifetime == 0:
            pygame.sprite.Sprite.kill(self)
            
        else:
            self.lifetime -= 1
            
        hit_list = pygame.sprite.spritecollide(self, self.enemies_group, True)
        
        for x in self.enemies_group:
            
            for x in hit_list:
                pygame.sprite.Sprite.kill(x)
