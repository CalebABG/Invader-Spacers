'''
Created on Jun 4, 2015

@author: Caleb BG
'''
from Game_types import *
from Tools_class import ScreenMessage
from pygame.locals import *

""" This class borrowed code from Jeremy Gagnier @ http://jergagnier.wix.com/projects, to
make the startup screen, all other code created myself """


game_type_one = Res_1()
game_type_two = Res_2()
game_type_three = Res_3()


class Res_Select:
    
    def start(self, screen):
        
        ft = pygame.font.SysFont("monospace", 60)
        
        self.window = screen
           
        key = pygame.key.get_pressed()
        pygame.event.pump()
        
        if key[K_ESCAPE]:
            pygame.quit()
            sys.exit()
        
        mx, my = pygame.mouse.get_pos()
        lc = pygame.mouse.get_pressed()[0]
        
        self.window.fill((255, 211, 107))
        
        ScreenMessage(self.window, "Resolution Select", (255, 61, 61), 50, 130, 10)
        ScreenMessage(self.window, "Smaller screen", (0, 0, 153), 24, 20, 130)
        ScreenMessage(self.window, "Default screen", (0, 0, 153), 24, 20, 285)
        ScreenMessage(self.window, "Larger screen", (0, 0, 153), 24, 20, 440)
        
        """ Borrowed code for selectable buttons (re-named things, but credit given to creator) """
        # Button for res mode 1
        game_select_one = ft.render('680 x 590', 1, (0, 0, 0)), ft.size('680 x 590')
        self.window.blit(game_select_one[0], (400-game_select_one[1][0]/2, 150-game_select_one[1][1]/2))
        
        if 400-game_select_one[1][0]/2 < mx < 400+game_select_one[1][0]/2 and 150-game_select_one[1][1]/2 < my < 150+game_select_one[1][1]/2:
            pygame.draw.rect(self.window, (0, 0, 0), (400-game_select_one[1][0]/2-10, 150-game_select_one[1][1]/2-5, game_select_one[1][0]+20, game_select_one[1][1]+10), 4)
            if lc:
                game_type_one.game_on()
        
        # Button for res mode 2
        game_select_two = ft.render('700 x 650', 1, (0, 0, 0)), ft.size('700 x 650')
        self.window.blit(game_select_two[0], (400-game_select_two[1][0]/2, 300-game_select_two[1][1]/2))
        
        if 400-game_select_two[1][0]/2 < mx < 400+game_select_two[1][0]/2 and 300-game_select_two[1][1]/2 < my < 300+game_select_two[1][1]/2:
            pygame.draw.rect(self.window, (0, 0, 0), (400-game_select_two[1][0]/2-10, 300-game_select_two[1][1]/2-5, game_select_two[1][0]+20, game_select_two[1][1]+10), 4)
            if lc:
                game_type_two.game_on()
        
        # Button for res mode 3
        game_select_three = ft.render('900 x 850', 1, (0, 0, 0)), ft.size('900 x 850')
        self.window.blit(game_select_three[0], (400-game_select_three[1][0]/2, 450-game_select_three[1][1]/2))
        
        if 400-game_select_three[1][0]/2 < mx < 400+game_select_three[1][0]/2 and 450-game_select_three[1][1]/2 < my < 450+game_select_three[1][1]/2:
            pygame.draw.rect(self.window, (0, 0, 0), (400-game_select_three[1][0]/2-10, 450-game_select_three[1][1]/2-5, game_select_three[1][0]+20, game_select_three[1][1]+10), 4)
            if lc:
                game_type_three.game_on()
