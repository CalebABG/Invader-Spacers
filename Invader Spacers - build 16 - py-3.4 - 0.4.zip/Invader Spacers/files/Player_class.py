'''
Created on May 18, 2015
@author: Caleb BG
'''

import pygame


class Player(pygame.sprite.Sprite):

    def __init__(self, displaywidth, displayheight):

        super(Player, self).__init__()
        
        self.displayw = displaywidth
        self.displayh = displayheight

        self.image = pygame.image.load("res/ship.png").convert_alpha()

        self.set_properties()

        self.hspeed = 0
        self.vspeed = 0

    def set_properties(self):

        self.rect = self.image.get_rect()

        self.origin_x = self.rect.centerx
        self.origin_y = self.rect.centery

    def set_position(self, x, y):

        self.rect.x = x - self.origin_x
        self.rect.y = y - self.origin_y
        
    def get_position(self):
        
        return (self.rect.x, self.rect.y) 

    def change_speed(self, hspeed, vspeed):

        self.hspeed += hspeed
        self.vspeed += vspeed

    def death(self):    
        pygame.sprite.Sprite.kill(self)

    def update(self, collidable):
        
        if self.rect.right > self.displayw:
            self.rect.right = self.displayw-8
            
        elif self.rect.left < 0:
            self.rect.left = 8
            
        if self.rect.bottom > self.displayh:
            self.rect.bottom = self.displayh-8
            
        elif self.rect.top < 0:
            self.rect.top = 8
         
        self.rect.x += self.hspeed
 
        collision_list = pygame.sprite.spritecollide(self, collidable, False)
 
        for collided_object in collision_list:
 
            if self.hspeed > 0:
 
                # Right
                self.rect.right = collided_object.rect.left
 
            elif self.hspeed < 0:
 
                # LEFT
                self.rect.left = collided_object.rect.right

        self.rect.y += self.vspeed
 
        collision_list = pygame.sprite.spritecollide(self, collidable, False)
 
        for collided_object in collision_list:
 
            if self.vspeed > 0:
 
                # Bottom
                self.rect.bottom = collided_object.rect.top
                self.vspeed = 0
 
            elif self.vspeed < 0:
 
                # Top
                self.rect.top = collided_object.rect.bottom
                self.vspeed = 0
