'''
Created on May 21, 2015

@author: Caleb BG
'''
from Explosions_class import *


class Aliens(pygame.sprite.Sprite):
    
    def __init__(self, displayw, displayh, spritegroup, player, playerspritegroup):
        
        super(Aliens, self).__init__()
        
        self.playersprite = player
        
        self.playergroup = playerspritegroup
        
        self.image = pygame.image.load("res/alien.png").convert_alpha()
        
        self.rect = self.image.get_rect()
        
        self.origin_x = self.rect.centerx
        self.origin_y = self.rect.centery
        
        self.displayWidth = displayw
        self.displayHeight = displayh
    
        self.hspeed = 0
        self.vspeed = 0
       
    def set_position(self, x, y):
        
        self.rect.x = x - self.origin_x
        self.rect.y = y - self.origin_y
            
    def changespeed(self, hspeed, vspeed):
        
        self.hspeed += hspeed
        self.vspeed += vspeed
        
    def death(self):    
        pygame.sprite.Sprite.kill(self)
    
    def update(self):
        
        self.rect.x += self.hspeed
        self.rect.y += self.vspeed
        
        if self.rect.y > self.displayHeight:
            self.death()
            
        hit_list = pygame.sprite.spritecollide(self, self.playergroup, True)
