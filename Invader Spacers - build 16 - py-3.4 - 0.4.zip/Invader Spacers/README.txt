STEPS:

1. If you've made it to this text file, your DONE! Locate Invader Spacers.exe and double click.
2. ENJOY!